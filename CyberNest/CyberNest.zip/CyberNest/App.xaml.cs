﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace CyberNest
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            // 1. Megjelenítjük a Login ablakot modal-ként
            LoginWindow loginWin = new LoginWindow();
            bool? result = loginWin.ShowDialog();

            // 2. Csak akkor nyitjuk meg a MainWindow-t, ha a DialogResult true
            if (result == true)
            {
                MainWindow mainWin = new MainWindow();
                mainWin.Show();
            }
            else
            {
                // Ha bezárták a login ablakot vagy sikertelen, leáll az app
                Shutdown();
            }
        }
    }

}
