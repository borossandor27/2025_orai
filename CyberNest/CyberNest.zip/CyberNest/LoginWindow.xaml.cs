﻿using System.Net.Http;
using System.Net.Http.Json;
using System.Windows;
using CyberNest;

namespace CyberNest
{
    /// <summary>
    /// Interaction logic for LoginWindow.xaml
    /// </summary>
    public partial class LoginWindow : Window
    {
        private static readonly HttpClient _client = new HttpClient();

        public LoginWindow() => InitializeComponent();

        private async void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            var loginData = new
            {
                elerhetoseg = EmailInput.Text,
                jelszo = PasswordInput.Password
            };

            try
            {
                var response = await _client.PostAsJsonAsync("http://localhost:5050/api/auth/login", loginData);

                if (response.IsSuccessStatusCode)
                {
                    var result = await response.Content.ReadFromJsonAsync<Dictionary<string, string>>();

                    if (result != null && result.ContainsKey("role") && result["role"] == "admin")
                    {
                        this.DialogResult = true; // Ez zárja be az ablakot sikeres jelzéssel
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Nincs admin jogosultságod!", "Hiba", MessageBoxButton.OK, MessageBoxImage.Warning);
                    }
                }
                else
                {
                    MessageBox.Show("Hibás adatok!", "Hiba", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Szerver hiba: {ex.Message}", "Hiba", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
